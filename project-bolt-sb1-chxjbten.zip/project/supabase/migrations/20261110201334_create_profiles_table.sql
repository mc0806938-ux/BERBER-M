/*
# Create profiles table for barbers and customers

1. New Tables
- `profiles`
  - `id` (uuid, primary key, same as the sign-in account id)
  - `role` (text, either 'customer' or 'barber', fixed at sign-up)
  - `full_name` (text, display name)
  - `phone` (text, optional contact number)
  - `created_at` (timestamptz)

2. Automation
- A trigger creates a profile automatically whenever a new account signs up, using the role and name chosen on the sign-up form.

3. Security
- Row level security enabled on `profiles`.
- Signed-in users can read only their own profile.
- Signed-in users can update only their own name and phone; the role cannot be changed after sign-up.
- No direct insert by clients; profiles are created only by the sign-up trigger.
- The trigger function is not callable by clients.

4. Notes
- Role values are validated when the profile is created.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('customer', 'barber')),
  full_name text NOT NULL DEFAULT '',
  phone text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON profiles TO authenticated;
GRANT UPDATE (full_name, phone) ON profiles TO authenticated;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_account()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  chosen_role text;
BEGIN
  chosen_role := COALESCE(NEW.raw_user_meta_data->>'role', 'customer');
  IF chosen_role NOT IN ('customer', 'barber') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;

  INSERT INTO public.profiles (id, role, full_name)
  VALUES (NEW.id, chosen_role, COALESCE(NEW.raw_user_meta_data->>'full_name', ''));

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_account() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_account();
