/*
# Barber salon management: photos, active flag, and locked-down access

1. Modified Tables
- `salons`: new `photo_path` (salon photo location) and `is_active` (true = visible to customers, default true).
- `profiles`: new `avatar_path` (profile photo location).

2. Access rules (grants)
- Removed all default table privileges from the anonymous role and the signed-in role on salons, services, working hours, appointments and profiles.
- Re-granted only the columns and actions the app needs:
  - profiles: a user can read their profile and change only name, phone and profile photo. The role can never be changed.
  - salons: owners can add a salon and change its name, address, phone, photo and active flag.
  - services and working hours: owners can add, change and (services) delete their rows.
  - appointments: customers can request appointments; both sides can change only the status.
- Clearing TRUNCATE, REFERENCES and TRIGGER from client roles so data cannot be wiped by the public API.

3. Row access
- Customers can see active salons and their own salon. Barbers can see their own salon in all cases.
- Barbers can see the profile name of customers who have appointments at their salon, and nothing else of other users.

4. Photo storage
- New public `salon-media` bucket for salon and profile photos: JPEG, PNG or WebP only, up to 5 MB.
- Signed-in users can upload, read and remove only files inside their own user folder.
- Photos are publicly viewable by link, so customers see them on salon pages.
*/

ALTER TABLE salons ADD COLUMN IF NOT EXISTS photo_path text;
ALTER TABLE salons ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS avatar_path text;

REVOKE ALL ON profiles, salons, services, working_hours, appointments FROM anon, authenticated;

GRANT SELECT ON profiles TO authenticated;
GRANT UPDATE (full_name, phone, avatar_path) ON profiles TO authenticated;

GRANT SELECT ON salons TO authenticated;
GRANT INSERT (name, address, phone) ON salons TO authenticated;
GRANT UPDATE (name, address, phone, photo_path, is_active) ON salons TO authenticated;
GRANT DELETE ON salons TO authenticated;

GRANT SELECT ON services TO authenticated;
GRANT INSERT (salon_id, name, price_try, duration_minutes) ON services TO authenticated;
GRANT UPDATE (name, price_try, duration_minutes) ON services TO authenticated;
GRANT DELETE ON services TO authenticated;

GRANT SELECT ON working_hours TO authenticated;
GRANT INSERT (salon_id, weekday, is_open, open_time, close_time) ON working_hours TO authenticated;
GRANT UPDATE (is_open, open_time, close_time) ON working_hours TO authenticated;
GRANT DELETE ON working_hours TO authenticated;

GRANT SELECT ON appointments TO authenticated;
GRANT INSERT (salon_id, service_id, starts_at) ON appointments TO authenticated;
GRANT UPDATE (status) ON appointments TO authenticated;

DROP POLICY IF EXISTS "select_salons" ON salons;
CREATE POLICY "select_salons" ON salons FOR SELECT
  TO authenticated USING (is_active OR owner_id = auth.uid());

DROP POLICY IF EXISTS "select_customers_of_my_salon" ON profiles;
CREATE POLICY "select_customers_of_my_salon" ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM appointments a
      JOIN salons s ON s.id = a.salon_id
      WHERE a.customer_id = profiles.id
        AND s.owner_id = auth.uid()
    )
  );

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('salon-media', 'salon-media', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp'])
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "salon_media_select_own" ON storage.objects;
CREATE POLICY "salon_media_select_own" ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'salon-media' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "salon_media_insert_own" ON storage.objects;
CREATE POLICY "salon_media_insert_own" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'salon-media' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "salon_media_delete_own" ON storage.objects;
CREATE POLICY "salon_media_delete_own" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'salon-media' AND (storage.foldername(name))[1] = auth.uid()::text);
