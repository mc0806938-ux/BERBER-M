/*
# Allow saving weekly hours in one step

1. Modified Access (grants)
- working_hours: owners may also update the salon and weekday columns of their own rows. Row ownership is still checked by the existing policies, so this does not open access to other salons.

2. Why
- Saving a full week at once uses an insert-or-update in one request, which needs update permission on every column it writes.
*/

GRANT UPDATE (salon_id, weekday) ON working_hours TO authenticated;
