/*
# Add username to profiles

1. Modified Tables
- `profiles`: new optional `username` column. Usernames are 3 to 20 characters and may contain only letters (A-Z), digits and underscores.

2. Uniqueness
- Usernames are unique regardless of letter case (for example "Ali" and "ali" cannot both exist).

3. Automation
- The sign-up trigger now saves the username chosen on the sign-up form, and uses it as the display name.

4. Security
- No new grants or policies. Users can read their own profile as before and cannot change their username after sign-up.
- Existing profiles keep working; their username stays empty until set.
*/

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS username text;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_username_format') THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_username_format
      CHECK (username IS NULL OR username ~ '^[A-Za-z0-9_]{3,20}$');
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique_idx
  ON profiles (lower(username))
  WHERE username IS NOT NULL;

CREATE OR REPLACE FUNCTION public.handle_new_account()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  chosen_role text;
  chosen_username text;
BEGIN
  chosen_role := COALESCE(NEW.raw_user_meta_data->>'role', 'customer');
  IF chosen_role NOT IN ('customer', 'barber') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;

  chosen_username := NULLIF(BTRIM(NEW.raw_user_meta_data->>'username'), '');

  INSERT INTO public.profiles (id, role, full_name, username)
  VALUES (NEW.id, chosen_role, COALESCE(chosen_username, ''), chosen_username);

  RETURN NEW;
END;
$$;
