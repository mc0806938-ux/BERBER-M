/*
# Create salons, services, working hours and appointments

1. New Tables
- `salons`: one salon per barber (owner_id). Name, address, phone.
- `services`: services offered by a salon with price (TRY) and duration.
- `working_hours`: open/closed status and opening/closing time for each weekday of a salon (0 = Sunday ... 6 = Saturday).
- `appointments`: a customer's request for a salon at a given start time. Status is 'pending' (waiting for barber), 'confirmed', 'rejected', or 'cancelled'.

2. Functions
- `get_booked_slots(salon, from, to)`: returns only the start times that are already taken (pending or confirmed), without exposing customer details.

3. Double booking protection
- A partial unique index on (salon_id, starts_at) for pending and confirmed appointments ensures two active appointments can never share the same time.

4. Security
- RLS enabled on all four tables.
- Salons, services and working hours are readable by signed-in users (public catalog); only the owning barber can change them.
- Customers can create pending appointments only for themselves and can cancel their own appointments.
- Barbers can see appointments for their salon and can only confirm or reject them.
- Clients cannot change any other appointment field than status.
- `get_booked_slots` is callable only by signed-in users.

5. Notes
- Booking slots are 30 minutes long.
- Times are stored as timestamps with time zone; the app interprets them in Istanbul time.
*/

CREATE TABLE IF NOT EXISTS salons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL UNIQUE DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(trim(name)) > 0),
  address text NOT NULL DEFAULT '',
  phone text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(trim(name)) > 0),
  price_try integer NOT NULL CHECK (price_try >= 0),
  duration_minutes integer NOT NULL CHECK (duration_minutes > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS services_salon_id_idx ON services(salon_id);

CREATE TABLE IF NOT EXISTS working_hours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  weekday smallint NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  is_open boolean NOT NULL DEFAULT true,
  open_time time NOT NULL,
  close_time time NOT NULL,
  UNIQUE (salon_id, weekday),
  CHECK (close_time > open_time)
);

CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  customer_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  starts_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'rejected', 'cancelled')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS appointments_active_slot_idx
  ON appointments (salon_id, starts_at)
  WHERE status IN ('pending', 'confirmed');
CREATE INDEX IF NOT EXISTS appointments_customer_id_idx ON appointments(customer_id);

ALTER TABLE salons ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE working_hours ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON salons, services, working_hours TO authenticated;
GRANT INSERT, UPDATE, DELETE ON salons, services, working_hours TO authenticated;
GRANT SELECT, INSERT ON appointments TO authenticated;
GRANT UPDATE (status) ON appointments TO authenticated;

-- Public catalog: any signed-in user can browse salons, services and hours.
DROP POLICY IF EXISTS "select_salons" ON salons;
CREATE POLICY "select_salons" ON salons FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_salon" ON salons;
CREATE POLICY "insert_own_salon" ON salons FOR INSERT
  TO authenticated
  WITH CHECK (
    owner_id = auth.uid()
    AND EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'barber')
  );

DROP POLICY IF EXISTS "update_own_salon" ON salons;
CREATE POLICY "update_own_salon" ON salons FOR UPDATE
  TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_salon" ON salons;
CREATE POLICY "delete_own_salon" ON salons FOR DELETE
  TO authenticated USING (owner_id = auth.uid());

DROP POLICY IF EXISTS "select_services" ON services;
CREATE POLICY "select_services" ON services FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_services" ON services;
CREATE POLICY "insert_own_services" ON services FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM salons WHERE salons.id = services.salon_id AND salons.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_own_services" ON services;
CREATE POLICY "update_own_services" ON services FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM salons WHERE salons.id = services.salon_id AND salons.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM salons WHERE salons.id = services.salon_id AND salons.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_own_services" ON services;
CREATE POLICY "delete_own_services" ON services FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM salons WHERE salons.id = services.salon_id AND salons.owner_id = auth.uid()));

DROP POLICY IF EXISTS "select_working_hours" ON working_hours;
CREATE POLICY "select_working_hours" ON working_hours FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_working_hours" ON working_hours;
CREATE POLICY "insert_own_working_hours" ON working_hours FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM salons WHERE salons.id = working_hours.salon_id AND salons.owner_id = auth.uid()));

DROP POLICY IF EXISTS "update_own_working_hours" ON working_hours;
CREATE POLICY "update_own_working_hours" ON working_hours FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM salons WHERE salons.id = working_hours.salon_id AND salons.owner_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM salons WHERE salons.id = working_hours.salon_id AND salons.owner_id = auth.uid()));

DROP POLICY IF EXISTS "delete_own_working_hours" ON working_hours;
CREATE POLICY "delete_own_working_hours" ON working_hours FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM salons WHERE salons.id = working_hours.salon_id AND salons.owner_id = auth.uid()));

-- Customers see their own appointments; barbers see appointments for their salon.
DROP POLICY IF EXISTS "select_appointments" ON appointments;
CREATE POLICY "select_appointments" ON appointments FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid()
    OR EXISTS (SELECT 1 FROM salons WHERE salons.id = appointments.salon_id AND salons.owner_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_appointments" ON appointments;
CREATE POLICY "insert_own_appointments" ON appointments FOR INSERT
  TO authenticated
  WITH CHECK (
    customer_id = auth.uid()
    AND status = 'pending'
    AND EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'customer')
  );

-- Customers may only cancel their own open appointments.
-- Barbers may only confirm or reject appointments for their salon.
DROP POLICY IF EXISTS "update_appointments" ON appointments;
CREATE POLICY "update_appointments" ON appointments FOR UPDATE
  TO authenticated
  USING (
    (customer_id = auth.uid() AND status IN ('pending', 'confirmed'))
    OR EXISTS (SELECT 1 FROM salons WHERE salons.id = appointments.salon_id AND salons.owner_id = auth.uid())
  )
  WITH CHECK (
    (customer_id = auth.uid() AND status = 'cancelled')
    OR (
      EXISTS (SELECT 1 FROM salons WHERE salons.id = appointments.salon_id AND salons.owner_id = auth.uid())
      AND status IN ('confirmed', 'rejected')
    )
  );

CREATE OR REPLACE FUNCTION public.get_booked_slots(p_salon_id uuid, p_from timestamptz, p_to timestamptz)
RETURNS TABLE (starts_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT a.starts_at
  FROM appointments a
  WHERE a.salon_id = p_salon_id
    AND a.status IN ('pending', 'confirmed')
    AND a.starts_at >= p_from
    AND a.starts_at < p_to;
$$;

REVOKE EXECUTE ON FUNCTION public.get_booked_slots(uuid, timestamptz, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_booked_slots(uuid, timestamptz, timestamptz) TO authenticated;
