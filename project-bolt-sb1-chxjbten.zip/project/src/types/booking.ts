export type AppointmentStatus = 'pending' | 'confirmed' | 'rejected' | 'cancelled';

export interface Service {
  id: string;
  salon_id: string;
  name: string;
  price_try: number;
  duration_minutes: number;
}

export interface WorkingHour {
  weekday: number;
  is_open: boolean;
  open_time: string;
  close_time: string;
}

export interface SalonDetails {
  id: string;
  name: string;
  address: string;
  phone: string | null;
  photo_path: string | null;
  is_active: boolean;
}

export interface Salon extends SalonDetails {
  services: Service[];
  working_hours: WorkingHour[];
}

export interface Appointment {
  id: string;
  starts_at: string;
  status: AppointmentStatus;
  salon_name: string;
  service_name: string;
  service_price_try: number;
}

export interface SalonAppointment {
  id: string;
  starts_at: string;
  status: AppointmentStatus;
  customer_name: string;
  service_name: string;
  service_price_try: number;
}
