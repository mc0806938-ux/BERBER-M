export type UserRole = 'customer' | 'barber';

export interface Profile {
  id: string;
  role: UserRole;
  full_name: string;
  phone: string | null;
  avatar_path: string | null;
}
