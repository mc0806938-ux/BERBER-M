import { supabase } from '@/lib/supabase';
import type {
  AppointmentStatus,
  SalonAppointment,
  SalonDetails,
  Service,
  WorkingHour,
} from '@/types/booking';

const LOAD_ERROR = 'Bilgiler yüklenemedi. Lütfen tekrar deneyin.';
const SAVE_ERROR = 'Kaydedilemedi. Lütfen tekrar deneyin.';

const SALON_COLUMNS = 'id, name, address, phone, photo_path, is_active';

export async function fetchOwnSalon(ownerId: string): Promise<SalonDetails | null> {
  const { data, error } = await supabase
    .from('salons')
    .select(SALON_COLUMNS)
    .eq('owner_id', ownerId)
    .maybeSingle();
  if (error) throw new Error(LOAD_ERROR);
  return data as SalonDetails | null;
}

export async function createSalon(input: { name: string; address: string; phone: string | null }): Promise<SalonDetails> {
  const { data, error } = await supabase.from('salons').insert(input).select(SALON_COLUMNS).single();
  if (error || !data) throw new Error(SAVE_ERROR);
  return data as SalonDetails;
}

export async function updateSalon(
  id: string,
  patch: Partial<Pick<SalonDetails, 'name' | 'address' | 'phone' | 'photo_path' | 'is_active'>>,
): Promise<SalonDetails> {
  const { data, error } = await supabase.from('salons').update(patch).eq('id', id).select(SALON_COLUMNS).maybeSingle();
  if (error || !data) throw new Error(SAVE_ERROR);
  return data as SalonDetails;
}

export async function fetchServices(salonId: string): Promise<Service[]> {
  const { data, error } = await supabase
    .from('services')
    .select('id, salon_id, name, price_try, duration_minutes')
    .eq('salon_id', salonId)
    .order('price_try');
  if (error || !Array.isArray(data)) throw new Error(LOAD_ERROR);
  return data as Service[];
}

export interface ServiceInput {
  name: string;
  price_try: number;
  duration_minutes: number;
}

export async function saveService(salonId: string, serviceId: string | null, input: ServiceInput): Promise<void> {
  const query = serviceId
    ? supabase.from('services').update(input).eq('id', serviceId)
    : supabase.from('services').insert({ ...input, salon_id: salonId });
  const { error } = await query;
  if (error) throw new Error(SAVE_ERROR);
}

export async function deleteService(serviceId: string): Promise<void> {
  const { error } = await supabase.from('services').delete().eq('id', serviceId);
  if (error?.code === '23503') {
    throw new Error('Bu hizmet mevcut randevularda kullanıldığı için silinemez.');
  }
  if (error) throw new Error('Hizmet silinemedi. Lütfen tekrar deneyin.');
}

export async function fetchWorkingHours(salonId: string): Promise<WorkingHour[]> {
  const { data, error } = await supabase
    .from('working_hours')
    .select('weekday, is_open, open_time, close_time')
    .eq('salon_id', salonId);
  if (error || !Array.isArray(data)) throw new Error(LOAD_ERROR);
  return data as WorkingHour[];
}

export async function saveWorkingHours(salonId: string, hours: WorkingHour[]): Promise<void> {
  const rows = hours.map((hour) => ({ salon_id: salonId, ...hour }));
  const { error } = await supabase.from('working_hours').upsert(rows, { onConflict: 'salon_id,weekday' });
  if (error) throw new Error(SAVE_ERROR);
}

interface SalonAppointmentRow {
  id: string;
  starts_at: string;
  status: AppointmentStatus;
  services: { name: string; price_try: number } | null;
  profiles: { full_name: string } | null;
}

export async function fetchSalonAppointments(salonId: string): Promise<SalonAppointment[]> {
  const { data, error } = await supabase
    .from('appointments')
    .select('id, starts_at, status, services(name, price_try), profiles(full_name)')
    .eq('salon_id', salonId)
    .order('starts_at', { ascending: true });
  if (error || !Array.isArray(data)) throw new Error(LOAD_ERROR);

  return (data as unknown as SalonAppointmentRow[]).map((row) => ({
    id: row.id,
    starts_at: row.starts_at,
    status: row.status,
    customer_name: row.profiles?.full_name || 'Müşteri',
    service_name: row.services?.name ?? '',
    service_price_try: row.services?.price_try ?? 0,
  }));
}

export async function setAppointmentDecision(id: string, status: 'confirmed' | 'rejected'): Promise<void> {
  const { error } = await supabase.from('appointments').update({ status }).eq('id', id);
  if (error) throw new Error('Karar kaydedilemedi. Lütfen tekrar deneyin.');
}

export async function updateAvatarPath(userId: string, avatarPath: string): Promise<void> {
  const { error } = await supabase.from('profiles').update({ avatar_path: avatarPath }).eq('id', userId);
  if (error) throw new Error(SAVE_ERROR);
}
