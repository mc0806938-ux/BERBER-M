export function formatPrice(priceTry: number): string {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    maximumFractionDigits: 0,
  }).format(priceTry);
}

export function formatDuration(minutes: number): string {
  return `${minutes} dk`;
}
