import { supabase } from '@/lib/supabase';
import { addDays, istanbulDateTimeToIso } from '@/lib/istanbulTime';
import type { Appointment, AppointmentStatus, Salon } from '@/types/booking';

export const SLOT_TAKEN_MESSAGE = 'Bu saat az önce başka bir müşteri tarafından alındı. Lütfen başka bir saat seçin.';
const LOAD_ERROR_MESSAGE = 'Bilgiler yüklenemedi. Lütfen tekrar deneyin.';

export async function fetchSalons(): Promise<Salon[]> {
  const { data, error } = await supabase
    .from('salons')
    .select(
      'id, name, address, phone, photo_path, is_active, services(id, salon_id, name, price_try, duration_minutes), working_hours(weekday, is_open, open_time, close_time)',
    )
    .order('name');
  if (error || !Array.isArray(data)) throw new Error(LOAD_ERROR_MESSAGE);
  return data as unknown as Salon[];
}

export async function fetchBookedSlots(salonId: string, date: string): Promise<string[]> {
  const { data, error } = await supabase.rpc('get_booked_slots', {
    p_salon_id: salonId,
    p_from: istanbulDateTimeToIso(date, '00:00'),
    p_to: istanbulDateTimeToIso(addDays(date, 1), '00:00'),
  });
  if (error || !Array.isArray(data)) throw new Error(LOAD_ERROR_MESSAGE);
  return (data as { starts_at: string }[]).map((row) => row.starts_at);
}

export async function createAppointmentRequest(params: {
  salonId: string;
  serviceId: string;
  date: string;
  time: string;
}): Promise<void> {
  const { error } = await supabase.from('appointments').insert({
    salon_id: params.salonId,
    service_id: params.serviceId,
    starts_at: istanbulDateTimeToIso(params.date, params.time),
  });
  if (error?.code === '23505') throw new Error(SLOT_TAKEN_MESSAGE);
  if (error) throw new Error('Randevu talebi gönderilemedi. Lütfen tekrar deneyin.');
}

interface AppointmentRow {
  id: string;
  starts_at: string;
  status: AppointmentStatus;
  salons: { name: string } | null;
  services: { name: string; price_try: number } | null;
}

export async function fetchMyAppointments(): Promise<Appointment[]> {
  const { data, error } = await supabase
    .from('appointments')
    .select('id, starts_at, status, salons(name), services(name, price_try)')
    .order('starts_at', { ascending: false });
  if (error || !Array.isArray(data)) throw new Error(LOAD_ERROR_MESSAGE);

  return (data as unknown as AppointmentRow[]).map((row) => ({
    id: row.id,
    starts_at: row.starts_at,
    status: row.status,
    salon_name: row.salons?.name ?? '',
    service_name: row.services?.name ?? '',
    service_price_try: row.services?.price_try ?? 0,
  }));
}

export async function cancelAppointment(id: string): Promise<void> {
  const { error } = await supabase.from('appointments').update({ status: 'cancelled' }).eq('id', id);
  if (error) throw new Error('Randevu iptal edilemedi. Lütfen tekrar deneyin.');
}
