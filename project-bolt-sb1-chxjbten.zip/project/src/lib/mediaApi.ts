import { supabase } from '@/lib/supabase';

const MEDIA_BUCKET = 'salon-media';
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const EXTENSIONS: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

export function validateImageFile(file: File): string | null {
  if (!EXTENSIONS[file.type]) return 'Lütfen JPEG, PNG veya WebP formatında bir fotoğraf seçin.';
  if (file.size > MAX_IMAGE_BYTES) return 'Fotoğraf en fazla 5 MB olabilir.';
  return null;
}

export async function uploadMedia(file: File, userId: string, kind: 'salon' | 'avatar'): Promise<string> {
  const extension = EXTENSIONS[file.type];
  if (!extension) throw new Error('Desteklenmeyen fotoğraf formatı.');
  const path = `${userId}/${kind}-${Date.now()}-${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage
    .from(MEDIA_BUCKET)
    .upload(path, file, { contentType: file.type, cacheControl: '3600' });
  if (error) throw new Error('Fotoğraf yüklenemedi. Lütfen tekrar deneyin.');
  return path;
}

export function getMediaUrl(path: string | null): string | null {
  if (!path) return null;
  return supabase.storage.from(MEDIA_BUCKET).getPublicUrl(path).data.publicUrl;
}

export async function removeMedia(path: string | null): Promise<void> {
  if (!path) return;
  await supabase.storage.from(MEDIA_BUCKET).remove([path]);
}
