export const SLOT_MINUTES = 30;

const ISTANBUL_TZ = 'Europe/Istanbul';
const ISTANBUL_OFFSET = '+03:00';

export function todayInIstanbul(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: ISTANBUL_TZ }).format(new Date());
}

export function addDays(date: string, days: number): string {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

export function weekdayOf(date: string): number {
  return new Date(`${date}T00:00:00Z`).getUTCDay();
}

export function istanbulDateTimeToIso(date: string, time: string): string {
  return `${date}T${time.slice(0, 5)}:00${ISTANBUL_OFFSET}`;
}

export function buildSlotTimes(openTime: string, closeTime: string): string[] {
  const toMinutes = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };
  const slots: string[] = [];
  const end = toMinutes(closeTime);
  for (let minutes = toMinutes(openTime); minutes + SLOT_MINUTES <= end; minutes += SLOT_MINUTES) {
    const hh = String(Math.floor(minutes / 60)).padStart(2, '0');
    const mm = String(minutes % 60).padStart(2, '0');
    slots.push(`${hh}:${mm}`);
  }
  return slots;
}

export function formatDayParts(date: string) {
  const value = new Date(istanbulDateTimeToIso(date, '12:00'));
  const weekday = new Intl.DateTimeFormat('tr-TR', { weekday: 'short', timeZone: ISTANBUL_TZ }).format(value);
  const day = new Intl.DateTimeFormat('tr-TR', { day: 'numeric', timeZone: ISTANBUL_TZ }).format(value);
  const month = new Intl.DateTimeFormat('tr-TR', { month: 'long', timeZone: ISTANBUL_TZ }).format(value);
  return { weekday, day, month };
}

export function formatAppointmentDateTime(iso: string): string {
  return new Intl.DateTimeFormat('tr-TR', {
    day: 'numeric',
    month: 'long',
    weekday: 'long',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: ISTANBUL_TZ,
  }).format(new Date(iso));
}
