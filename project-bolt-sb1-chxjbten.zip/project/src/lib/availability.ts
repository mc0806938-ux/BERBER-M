import { buildSlotTimes, istanbulDateTimeToIso, weekdayOf } from '@/lib/istanbulTime';
import type { WorkingHour } from '@/types/booking';

export function getOpenHours(workingHours: WorkingHour[], date: string): WorkingHour | null {
  const day = workingHours.find((hour) => hour.weekday === weekdayOf(date));
  return day && day.is_open ? day : null;
}

export function getAvailableSlots(
  workingHours: WorkingHour[],
  date: string,
  bookedIsoTimes: string[],
  now: number,
): string[] {
  const hours = getOpenHours(workingHours, date);
  if (!hours) return [];

  const booked = new Set(bookedIsoTimes.map((iso) => new Date(iso).getTime()));
  return buildSlotTimes(hours.open_time, hours.close_time).filter((time) => {
    const start = new Date(istanbulDateTimeToIso(date, time)).getTime();
    return start > now && !booked.has(start);
  });
}
