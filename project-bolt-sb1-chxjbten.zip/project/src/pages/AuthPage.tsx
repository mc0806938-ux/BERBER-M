import { useState, type FormEvent, type ReactNode } from 'react';
import { ArrowLeft, Eye, EyeOff, Loader2 } from 'lucide-react';
import BrandLogo from '@/components/BrandLogo';
import { useAuth } from '@/contexts/AuthContext';
import type { UserRole } from '@/types/profile';

type AuthMode = 'login' | 'signup';

interface AuthPageProps {
  role: UserRole;
  onBack: () => void;
}

const ROLE_COPY: Record<UserRole, { title: string; subtitle: string; panelTitle: string; panelText: string }> = {
  customer: {
    title: 'Müşteri girişi',
    subtitle: 'Berberleri keşfedin ve boş saatinize randevu alın.',
    panelTitle: 'Saçınız için en uygun saat sizi bekliyor.',
    panelText: 'Berberinizi seçin, tarih ve boş saatinizi belirleyin. Randevunuz berber onayıyla kesinleşir.',
  },
  barber: {
    title: 'Berber girişi',
    subtitle: 'Salonunuzu kurun, hizmetlerinizi ve çalışma saatlerinizi yönetin.',
    panelTitle: 'Salonunuz, randevularınız, tek ekranda.',
    panelText: 'Hizmetlerinizi ve fiyatlarınızı ekleyin, gelen randevuları onaylayın ya da reddedin.',
  },
};

export default function AuthPage({ role, onBack }: AuthPageProps) {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<AuthMode>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const copy = ROLE_COPY[role];
  const isSignup = mode === 'signup';

  const switchMode = (next: AuthMode) => {
    setMode(next);
    setError(null);
    setNotice(null);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setNotice(null);

    const trimmedEmail = email.trim();
    const trimmedUsername = username.trim();
    if (!trimmedEmail || !password) {
      setError('Lütfen e-posta ve şifrenizi girin.');
      return;
    }
    if (isSignup && !USERNAME_PATTERN.test(trimmedUsername)) {
      setError('Kullanıcı adı 3-20 karakter olmalı; yalnızca harf, rakam ve alt çizgi (_) içerebilir.');
      return;
    }
    if (isSignup && password.length < 6) {
      setError('Şifre en az 6 karakter olmalı.');
      return;
    }

    setSubmitting(true);
    if (isSignup) {
      const result = await signUp({ email: trimmedEmail, password, username: trimmedUsername, role });
      setSubmitting(false);
      if (result.status === 'error') {
        setError(result.message);
      } else if (result.status === 'check_email') {
        setPassword('');
        setMode('login');
        setNotice('Hesabınız oluşturuldu. Şimdi e-posta ve şifrenizle giriş yapabilirsiniz.');
      }
      return;
    }

    const result = await signIn(trimmedEmail, password, role);
    setSubmitting(false);
    if (result) setError(result);
  };

  return (
    <div className="flex min-h-screen flex-col bg-white md:flex-row">
      <aside className="relative hidden overflow-hidden bg-forest-900 p-12 text-white md:flex md:w-[44%] md:flex-col md:justify-between lg:p-16">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-forest-700/40" />
        <div className="absolute -bottom-32 -left-16 h-80 w-80 rounded-full bg-forest-800/60" />
        <div className="relative">
          <BrandLogo tone="light" />
        </div>
        <div className="relative max-w-md animate-fade-up">
          <h2 className="text-3xl font-bold leading-tight lg:text-4xl">{copy.panelTitle}</h2>
          <p className="mt-4 text-base leading-relaxed text-forest-100/85">{copy.panelText}</p>
        </div>
        <p className="relative text-sm text-forest-100/70">Berberim ile randevular hiç olmadığı kadar kolay.</p>
      </aside>

      <main className="flex flex-1 flex-col">
        <div className="flex h-16 items-center justify-between px-5 sm:px-8">
          <button
            type="button"
            onClick={onBack}
            className="-ml-2 flex items-center gap-1.5 rounded-full px-2.5 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50"
          >
            <ArrowLeft className="h-4 w-4" />
            Ana sayfa
          </button>
          <div className="md:hidden">
            <BrandLogo />
          </div>
        </div>

        <div className="flex flex-1 items-start justify-center px-5 pb-12 pt-4 sm:px-8 md:items-center md:pt-0">
          <div className="w-full max-w-md animate-fade-up">
            <h1 className="text-3xl font-bold tracking-tight text-forest-950">{copy.title}</h1>
            <p className="mt-2 text-sm leading-relaxed text-forest-800/75">{copy.subtitle}</p>

            <div className="mt-8 grid grid-cols-2 rounded-xl bg-forest-50 p-1" role="tablist">
              {(['login', 'signup'] as AuthMode[]).map((item) => (
                <button
                  key={item}
                  type="button"
                  role="tab"
                  aria-selected={mode === item}
                  onClick={() => switchMode(item)}
                  className={`rounded-lg py-2.5 text-sm font-semibold transition-all ${
                    mode === item
                      ? 'bg-forest-800 text-white shadow-card'
                      : 'text-forest-800/70 hover:text-forest-900'
                  }`}
                >
                  {item === 'login' ? 'Giriş Yap' : 'Hesap Oluştur'}
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
              {isSignup && (
                <Field label="Kullanıcı adı">
                  <input
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(event) => setUsername(event.target.value)}
                    placeholder={role === 'barber' ? 'ornek_berber' : 'ornek_musteri'}
                    className={inputClass}
                  />
                  <span className="mt-1.5 block text-xs text-forest-800/60">3-20 karakter; harf, rakam ve _ kullanın.</span>
                </Field>
              )}

              <Field label="E-posta">
                <input
                  type="email"
                  autoComplete="email"
                  inputMode="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="ornek@eposta.com"
                  className={inputClass}
                />
              </Field>

              <Field label="Şifre">
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    autoComplete={isSignup ? 'new-password' : 'current-password'}
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    placeholder={isSignup ? 'En az 6 karakter' : 'Şifreniz'}
                    className={`${inputClass} pr-12`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    aria-label={showPassword ? 'Şifreyi gizle' : 'Şifreyi göster'}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-forest-700/70 transition-colors hover:bg-forest-50 hover:text-forest-900"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </Field>

              {notice && (
                <p role="status" className="rounded-xl border border-forest-200 bg-forest-50 px-4 py-3 text-sm font-medium text-forest-800">
                  {notice}
                </p>
              )}

              {error && (
                <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-forest-800 py-3.5 text-sm font-bold text-white shadow-card transition-all hover:bg-forest-700 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-70"
              >
                {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                {submitting ? 'Lütfen bekleyin' : isSignup ? 'Hesabımı Oluştur' : 'Giriş Yap'}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-forest-800/75">
              {isSignup ? 'Zaten hesabınız var mı?' : 'Henüz hesabınız yok mu?'}{' '}
              <button
                type="button"
                onClick={() => switchMode(isSignup ? 'login' : 'signup')}
                className="font-bold text-forest-800 underline-offset-4 hover:underline"
              >
                {isSignup ? 'Giriş yapın' : 'Hesap oluşturun'}
              </button>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

const USERNAME_PATTERN = /^[A-Za-z0-9_]{3,20}$/;

const inputClass =
  'w-full rounded-xl border border-forest-200 bg-white px-4 py-3 text-sm text-forest-950 placeholder:text-forest-800/40 transition-colors focus:border-forest-600 focus:outline-none focus:ring-4 focus:ring-forest-100';

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-forest-900">{label}</span>
      {children}
    </label>
  );
}
