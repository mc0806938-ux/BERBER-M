import { BadgeCheck, CalendarCheck, Clock, Store } from 'lucide-react';
import BrandLogo from '@/components/BrandLogo';
import type { UserRole } from '@/types/profile';

interface HomePageProps {
  onSelectRole: (role: UserRole) => void;
}

const FEATURES = [
  {
    icon: Store,
    title: 'Berberleri keşfedin',
    text: 'Yakınınızdaki salonları, hizmetleri ve fiyatları tek ekranda görün.',
  },
  {
    icon: Clock,
    title: 'Boş saatinizi seçin',
    text: 'Size uygun tarihi ve boş saati seçin, sıra beklemeden randevunuzu oluşturun.',
  },
  {
    icon: BadgeCheck,
    title: 'Onayla kesinleşsin',
    text: 'Berberiniz randevunuzu onayladığında saatiniz kesinleşir ve çakışma olmaz.',
  },
];

export default function HomePage({ onSelectRole }: HomePageProps) {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      <header className="sticky top-0 z-30 border-b border-forest-100/70 bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <BrandLogo />
          <nav className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSelectRole('customer')}
              className="rounded-full px-3.5 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50 sm:px-4"
            >
              Müşteri Girişi
            </button>
            <button
              type="button"
              onClick={() => onSelectRole('barber')}
              className="rounded-full bg-forest-800 px-3.5 py-2 text-sm font-semibold text-white transition-colors hover:bg-forest-700 sm:px-4"
            >
              Berber Girişi
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-10 sm:px-8 md:grid-cols-2 md:gap-12 md:pb-24 md:pt-20">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full bg-forest-50 px-3 py-1.5 text-xs font-semibold text-forest-700">
              <span className="h-1.5 w-1.5 rounded-full bg-forest-500" />
              Berber randevusu artık çok kolay
            </span>
            <h1 className="mt-5 text-4xl font-bold leading-[1.15] tracking-tight text-forest-950 sm:text-5xl">
              Berberinizi seçin, saatinizi kendiniz ayırtın.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-forest-800/80 sm:text-lg">
              Berberim, müşterilerin boş saatlere anında randevu almasını, berberlerin ise salonlarını,
              hizmetlerini ve çalışma saatlerini tek yerden yönetmesini sağlar.
            </p>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => onSelectRole('customer')}
                className="group flex items-center justify-between gap-4 rounded-2xl bg-forest-800 p-5 text-left text-white shadow-card transition-all hover:-translate-y-0.5 hover:bg-forest-700"
              >
                <span>
                  <span className="block text-base font-bold">Randevu almak istiyorum</span>
                  <span className="mt-1 block text-sm text-forest-100/80">Müşteri girişi</span>
                </span>
                <CalendarCheck className="h-7 w-7 shrink-0 transition-transform group-hover:scale-110" />
              </button>
              <button
                type="button"
                onClick={() => onSelectRole('barber')}
                className="group flex items-center justify-between gap-4 rounded-2xl border border-forest-200 bg-white p-5 text-left text-forest-900 shadow-card transition-all hover:-translate-y-0.5 hover:border-forest-300"
              >
                <span>
                  <span className="block text-base font-bold">Salonumu yönetmek istiyorum</span>
                  <span className="mt-1 block text-sm text-forest-800/70">Berber girişi</span>
                </span>
                <Store className="h-7 w-7 shrink-0 text-forest-700 transition-transform group-hover:scale-110" />
              </button>
            </div>
          </div>

          <div className="relative animate-fade-up">
            <div className="absolute -inset-3 -z-10 rounded-[2rem] bg-forest-100/70" />
            <img
              src="https://images.pexels.com/photos/37764947/pexels-photo-37764947.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
              alt="Yeşil berber koltukları olan klasik bir berber salonu"
              className="aspect-[4/3] w-full rounded-3xl object-cover shadow-card md:aspect-[5/6]"
            />
          </div>
        </section>

        <section className="border-t border-forest-100 bg-forest-50/50">
          <div className="mx-auto grid max-w-6xl gap-5 px-5 py-14 sm:px-8 md:grid-cols-3 md:py-20">
            {FEATURES.map(({ icon: Icon, title, text }) => (
              <article
                key={title}
                className="rounded-2xl border border-forest-100 bg-white p-6 shadow-card transition-transform hover:-translate-y-1"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-forest-800 text-white">
                  <Icon className="h-5 w-5" />
                </span>
                <h2 className="mt-5 text-lg font-bold text-forest-950">{title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-forest-800/75">{text}</p>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-forest-100 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-6 text-sm text-forest-800/70 sm:flex-row sm:px-8">
          <BrandLogo />
          <p>© {new Date().getFullYear()} Berberim. Tüm hakları saklıdır.</p>
        </div>
      </footer>
    </div>
  );
}
