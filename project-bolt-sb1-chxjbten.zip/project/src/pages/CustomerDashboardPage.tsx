import { useState } from 'react';
import { CalendarDays, LogOut, Store } from 'lucide-react';
import BrandLogo from '@/components/BrandLogo';
import MyAppointments from '@/components/customer/MyAppointments';
import SalonList from '@/components/customer/SalonList';
import { useAuth } from '@/contexts/AuthContext';

type CustomerTab = 'barbers' | 'appointments';

const TABS: { id: CustomerTab; label: string; icon: typeof Store }[] = [
  { id: 'barbers', label: 'Berberler', icon: Store },
  { id: 'appointments', label: 'Randevularım', icon: CalendarDays },
];

export default function CustomerDashboardPage() {
  const { profile, signOut } = useAuth();
  const [tab, setTab] = useState<CustomerTab>('barbers');
  const firstName = profile?.full_name.trim().split(' ')[0] || 'Müşteri';

  return (
    <div className="flex min-h-screen flex-col bg-forest-50/60">
      <header className="sticky top-0 z-30 border-b border-forest-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-5 sm:px-8">
          <BrandLogo />
          <button
            type="button"
            onClick={signOut}
            aria-label="Çıkış yap"
            className="flex items-center gap-2 rounded-full px-3 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Çıkış yap</span>
          </button>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-8 sm:px-8 sm:py-10">
        <p className="text-sm font-semibold text-forest-600">Hoş geldiniz, {firstName}</p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight text-forest-950 sm:text-3xl">
          Saçınız için en uygun saati seçin
        </h1>

        <div className="mt-6 grid max-w-md grid-cols-2 rounded-xl bg-white p-1 shadow-card" role="tablist">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition-all ${
                tab === id ? 'bg-forest-800 text-white shadow-card' : 'text-forest-800/70 hover:text-forest-900'
              }`}
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>

        <div className="mt-8 animate-fade-up">
          {tab === 'barbers' ? <SalonList /> : <MyAppointments />}
        </div>
      </main>
    </div>
  );
}
