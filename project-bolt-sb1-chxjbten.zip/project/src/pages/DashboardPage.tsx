import { CircleAlert, LogOut, Scissors } from 'lucide-react';
import BrandLogo from '@/components/BrandLogo';
import { useAuth } from '@/contexts/AuthContext';
import CustomerDashboardPage from '@/pages/CustomerDashboardPage';

export default function DashboardPage() {
  const { profile, signOut } = useAuth();

  if (!profile) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-forest-50 px-5 text-center">
        <CircleAlert className="h-10 w-10 text-forest-700" />
        <p className="max-w-sm text-sm leading-relaxed text-forest-900">
          Hesap bilgileriniz yüklenemedi. Lütfen tekrar giriş yapın.
        </p>
        <button
          type="button"
          onClick={signOut}
          className="rounded-xl bg-forest-800 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-forest-700"
        >
          Çıkış yap
        </button>
      </div>
    );
  }

  if (profile.role === 'customer') return <CustomerDashboardPage />;

  const greetingName = profile.full_name || 'Berber';

  return (
    <div className="flex min-h-screen flex-col bg-forest-50/60">
      <header className="border-b border-forest-100 bg-white">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-5 sm:px-8">
          <BrandLogo />
          <button
            type="button"
            onClick={signOut}
            className="flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50"
          >
            <LogOut className="h-4 w-4" />
            Çıkış yap
          </button>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-10 sm:px-8">
        <p className="text-sm font-semibold text-forest-600">Berber paneli</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight text-forest-950">Hoş geldiniz, {greetingName}</h1>

        <div className="mt-8 flex flex-col items-start gap-4 rounded-2xl border border-dashed border-forest-300 bg-white p-8 shadow-card sm:flex-row sm:items-center">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-forest-800 text-white">
            <Scissors className="h-6 w-6" />
          </span>
          <div>
            <h2 className="text-lg font-bold text-forest-950">Salonunuz hazırlanıyor</h2>
            <p className="mt-1 text-sm leading-relaxed text-forest-800/75">
              Salon bilgileri, hizmetler ve çalışma saatleri sonraki adımda eklenecek.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
