import { useState, type ReactNode } from 'react';
import { CircleAlert, Loader2, Upload } from 'lucide-react';
import { validateImageFile } from '@/lib/mediaApi';

interface PhotoUploaderProps {
  title: string;
  hint: string;
  imageUrl: string | null;
  shape: 'square' | 'wide';
  fallback: ReactNode;
  onUpload: (file: File) => Promise<void>;
}

export default function PhotoUploader({ title, hint, imageUrl, shape, fallback, onUpload }: PhotoUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    const validation = validateImageFile(file);
    if (validation) {
      setError(validation);
      return;
    }

    setError(null);
    setUploading(true);
    try {
      await onUpload(file);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Fotoğraf yüklenemedi.');
    } finally {
      setUploading(false);
    }
  };

  const frameClass = shape === 'square' ? 'h-24 w-24 rounded-2xl' : 'aspect-[16/9] w-full rounded-2xl';

  return (
    <div className={shape === 'square' ? 'flex items-center gap-5' : 'space-y-3'}>
      <div className={`relative shrink-0 overflow-hidden bg-forest-800 ${frameClass} flex items-center justify-center text-white`}>
        {imageUrl ? (
          <img src={imageUrl} alt={title} className="h-full w-full object-cover" />
        ) : (
          fallback
        )}
        {uploading && (
          <span className="absolute inset-0 flex items-center justify-center bg-forest-950/50">
            <Loader2 className="h-6 w-6 animate-spin text-white" />
          </span>
        )}
      </div>

      <div className="min-w-0">
        {shape === 'square' && (
          <>
            <p className="text-sm font-bold text-forest-950">{title}</p>
            <p className="mt-0.5 text-xs text-forest-800/70">{hint}</p>
          </>
        )}
        {shape === 'wide' && (
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm font-bold text-forest-950">{title}</p>
              <p className="mt-0.5 text-xs text-forest-800/70">{hint}</p>
            </div>
          </div>
        )}
        <label className="mt-3 inline-flex cursor-pointer items-center gap-2 rounded-xl border border-forest-200 bg-white px-3.5 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50">
          <Upload className="h-4 w-4" />
          {imageUrl ? 'Fotoğrafı değiştir' : 'Fotoğraf ekle'}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleChange}
            disabled={uploading}
            className="sr-only"
          />
        </label>
        {error && (
          <p role="alert" className="mt-2 flex items-center gap-1.5 text-xs font-medium text-red-700">
            <CircleAlert className="h-3.5 w-3.5 shrink-0" />
            {error}
          </p>
        )}
      </div>
    </div>
  );
}
