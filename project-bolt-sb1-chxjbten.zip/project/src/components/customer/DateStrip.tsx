import { formatDayParts } from '@/lib/istanbulTime';

export interface DateOption {
  date: string;
  isOpen: boolean;
}

interface DateStripProps {
  options: DateOption[];
  selected: string | null;
  onSelect: (date: string) => void;
}

export default function DateStrip({ options, selected, onSelect }: DateStripProps) {
  return (
    <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 sm:-mx-6 sm:px-6 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      {options.map(({ date, isOpen }) => {
        const { weekday, day, month } = formatDayParts(date);
        const isSelected = selected === date;
        return (
          <button
            key={date}
            type="button"
            disabled={!isOpen}
            onClick={() => onSelect(date)}
            aria-pressed={isSelected}
            className={`flex w-16 shrink-0 flex-col items-center rounded-2xl border px-2 py-3 transition-all ${
              isSelected
                ? 'border-forest-800 bg-forest-800 text-white shadow-card'
                : isOpen
                  ? 'border-forest-100 bg-white text-forest-900 hover:border-forest-300'
                  : 'cursor-not-allowed border-transparent bg-forest-50 text-forest-800/35 line-through'
            }`}
          >
            <span className={`text-xs font-semibold ${isSelected ? 'text-forest-100' : ''}`}>{weekday}</span>
            <span className="mt-1 text-xl font-bold">{day}</span>
            <span className={`text-[11px] ${isSelected ? 'text-forest-100' : 'text-forest-800/60'}`}>{month.slice(0, 3)}</span>
          </button>
        );
      })}
    </div>
  );
}
