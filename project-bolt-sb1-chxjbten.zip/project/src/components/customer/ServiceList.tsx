import { ChevronRight, Clock } from 'lucide-react';
import { formatDuration, formatPrice } from '@/lib/format';
import type { Service } from '@/types/booking';

interface ServiceListProps {
  services: Service[];
  onPick: (service: Service) => void;
}

export default function ServiceList({ services, onPick }: ServiceListProps) {
  if (services.length === 0) {
    return (
      <p className="rounded-2xl bg-forest-50 p-6 text-center text-sm text-forest-800/80">
        Bu salon henüz hizmet eklemedi. Lütfen daha sonra tekrar deneyin.
      </p>
    );
  }

  return (
    <div>
      <p className="mb-3 text-sm font-semibold text-forest-800/80">Hizmetler ve fiyatlar</p>
      <ul className="space-y-3">
        {services.map((service) => (
          <li key={service.id}>
            <button
              type="button"
              onClick={() => onPick(service)}
              className="group flex w-full items-center justify-between gap-4 rounded-2xl border border-forest-100 bg-white p-4 text-left transition-all hover:border-forest-300 hover:bg-forest-50/50"
            >
              <span className="min-w-0">
                <span className="block text-base font-semibold text-forest-950">{service.name}</span>
                <span className="mt-1 flex items-center gap-1.5 text-sm text-forest-800/70">
                  <Clock className="h-3.5 w-3.5" />
                  {formatDuration(service.duration_minutes)}
                </span>
              </span>
              <span className="flex shrink-0 items-center gap-2">
                <span className="text-base font-bold text-forest-800">{formatPrice(service.price_try)}</span>
                <ChevronRight className="h-4 w-4 text-forest-600 transition-transform group-hover:translate-x-0.5" />
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
