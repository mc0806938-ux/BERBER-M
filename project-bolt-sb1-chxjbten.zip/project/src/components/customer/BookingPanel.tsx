import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, BadgeCheck, Clock, Loader2 } from 'lucide-react';
import DateStrip, { type DateOption } from '@/components/customer/DateStrip';
import { getAvailableSlots, getOpenHours } from '@/lib/availability';
import {
  createAppointmentRequest,
  fetchBookedSlots,
  SLOT_TAKEN_MESSAGE,
} from '@/lib/bookingApi';
import { addDays, todayInIstanbul } from '@/lib/istanbulTime';
import { formatDuration, formatPrice } from '@/lib/format';
import type { Salon, Service } from '@/types/booking';

const BOOKING_WINDOW_DAYS = 14;

interface BookingPanelProps {
  salon: Salon;
  service: Service;
  onBack: () => void;
  onDone: () => void;
}

interface BookedState {
  date: string;
  times: string[];
}

export default function BookingPanel({ salon, service, onBack, onDone }: BookingPanelProps) {
  const options: DateOption[] = useMemo(() => {
    const today = todayInIstanbul();
    return Array.from({ length: BOOKING_WINDOW_DAYS }, (_, index) => {
      const date = addDays(today, index);
      return { date, isOpen: getOpenHours(salon.working_hours, date) !== null };
    });
  }, [salon.working_hours]);

  const [date, setDate] = useState<string | null>(options.find((option) => option.isOpen)?.date ?? null);
  const [time, setTime] = useState<string | null>(null);
  const [booked, setBooked] = useState<BookedState | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (!date) return;
    let active = true;
    fetchBookedSlots(salon.id, date)
      .then((times) => {
        if (active) setBooked({ date, times });
      })
      .catch((err: Error) => {
        if (active) setLoadError(err.message);
      });
    return () => {
      active = false;
    };
  }, [date, salon.id, reloadKey]);

  const selectDate = (nextDate: string) => {
    setDate(nextDate);
    setTime(null);
    setBooked(null);
    setLoadError(null);
    setSubmitError(null);
  };

  const slotsReady = booked !== null && booked.date === date;
  const slots =
    date && slotsReady ? getAvailableSlots(salon.working_hours, date, booked.times, Date.now()) : [];

  const confirm = async () => {
    if (!date || !time) return;
    setSubmitting(true);
    setSubmitError(null);
    try {
      await createAppointmentRequest({ salonId: salon.id, serviceId: service.id, date, time });
      setSent(true);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Randevu talebi gönderilemedi. Lütfen tekrar deneyin.';
      setSubmitError(message);
      if (message === SLOT_TAKEN_MESSAGE) {
        setTime(null);
        setBooked(null);
        setReloadKey((key) => key + 1);
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (sent) {
    return (
      <div className="flex flex-col items-center py-8 text-center animate-fade-up">
        <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-forest-800 text-white">
          <BadgeCheck className="h-8 w-8" />
        </span>
        <h3 className="mt-5 text-xl font-bold text-forest-950">Randevu talebiniz alındı</h3>
        <p className="mt-2 max-w-sm text-sm leading-relaxed text-forest-800/75">
          Berber onayladığında randevunuz kesinleşecek. Durumunu Randevularım sekmesinden takip edebilirsiniz.
        </p>
        <button
          type="button"
          onClick={onDone}
          className="mt-6 rounded-xl bg-forest-800 px-6 py-3 text-sm font-bold text-white transition-colors hover:bg-forest-700"
        >
          Tamam
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <button
        type="button"
        onClick={onBack}
        className="-ml-2 flex items-center gap-1.5 rounded-full px-2.5 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50"
      >
        <ArrowLeft className="h-4 w-4" />
        Hizmetlere dön
      </button>

      <div className="flex items-center justify-between rounded-2xl bg-forest-50 p-4">
        <div>
          <p className="text-sm font-bold text-forest-950">{service.name}</p>
          <p className="mt-0.5 text-xs text-forest-800/70">{formatDuration(service.duration_minutes)}</p>
        </div>
        <p className="text-base font-bold text-forest-800">{formatPrice(service.price_try)}</p>
      </div>

      <section>
        <h3 className="mb-3 text-sm font-bold text-forest-950">Tarih seçin</h3>
        <DateStrip options={options} selected={date} onSelect={selectDate} />
      </section>

      <section>
        <h3 className="mb-3 text-sm font-bold text-forest-950">Boş saatler</h3>
        {!date ? (
          <p className="rounded-xl bg-forest-50 p-4 text-sm text-forest-800/80">
            Önümüzdeki {BOOKING_WINDOW_DAYS} gün için bu salonda açık gün bulunmuyor.
          </p>
        ) : loadError ? (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4">
            <p className="text-sm font-medium text-red-700">{loadError}</p>
            <button
              type="button"
              onClick={() => {
                setLoadError(null);
                setReloadKey((key) => key + 1);
              }}
              className="mt-3 text-sm font-semibold text-red-700 underline-offset-4 hover:underline"
            >
              Tekrar dene
            </button>
          </div>
        ) : !slotsReady ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-forest-600" />
          </div>
        ) : slots.length === 0 ? (
          <p className="rounded-xl bg-forest-50 p-4 text-sm text-forest-800/80">
            Bu tarih için uygun saat kalmadı. Lütfen başka bir gün seçin.
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {slots.map((slot) => (
              <button
                key={slot}
                type="button"
                onClick={() => setTime(slot)}
                aria-pressed={time === slot}
                className={`rounded-xl border py-2.5 text-sm font-semibold transition-all ${
                  time === slot
                    ? 'border-forest-800 bg-forest-800 text-white shadow-card'
                    : 'border-forest-100 bg-white text-forest-900 hover:border-forest-300 hover:bg-forest-50'
                }`}
              >
                {slot}
              </button>
            ))}
          </div>
        )}
      </section>

      {submitError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
          {submitError}
        </p>
      )}

      <div className="sticky bottom-0 -mx-5 flex items-center gap-4 border-t border-forest-100 bg-white px-5 py-4 sm:-mx-6 sm:px-6">
        <div className="min-w-0 flex-1 text-sm">
          {time && date ? (
            <p className="flex items-center gap-1.5 font-semibold text-forest-950">
              <Clock className="h-4 w-4 shrink-0 text-forest-600" />
              <span className="truncate">{time} saati seçildi</span>
            </p>
          ) : (
            <p className="text-forest-800/70">Tarih ve saat seçin</p>
          )}
        </div>
        <button
          type="button"
          onClick={confirm}
          disabled={!date || !time || submitting}
          className="flex shrink-0 items-center gap-2 rounded-xl bg-forest-800 px-5 py-3 text-sm font-bold text-white transition-all hover:bg-forest-700 disabled:cursor-not-allowed disabled:opacity-45"
        >
          {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
          Randevu talebi gönder
        </button>
      </div>
    </div>
  );
}
