import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import BookingPanel from '@/components/customer/BookingPanel';
import ServiceList from '@/components/customer/ServiceList';
import type { Salon, Service } from '@/types/booking';

interface SalonSheetProps {
  salon: Salon;
  onClose: () => void;
}

export default function SalonSheet({ salon, onClose }: SalonSheetProps) {
  const [chosenService, setChosenService] = useState<Service | null>(null);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6" role="dialog" aria-modal="true">
      <button
        type="button"
        aria-label="Kapat"
        onClick={onClose}
        className="absolute inset-0 animate-fade-in bg-forest-950/50 backdrop-blur-[2px]"
      />
      <div className="relative flex max-h-[92vh] w-full max-w-xl animate-sheet-up flex-col overflow-hidden rounded-t-3xl bg-white shadow-card sm:max-h-[85vh] sm:rounded-3xl">
        <div className="flex items-start justify-between gap-4 border-b border-forest-100 px-5 py-4 sm:px-6">
          <div className="min-w-0">
            <h2 className="truncate text-lg font-bold text-forest-950">{salon.name}</h2>
            {salon.address && <p className="mt-0.5 truncate text-sm text-forest-800/70">{salon.address}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Kapat"
            className="shrink-0 rounded-full p-2 text-forest-800 transition-colors hover:bg-forest-50"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">
          {chosenService ? (
            <BookingPanel
              salon={salon}
              service={chosenService}
              onBack={() => setChosenService(null)}
              onDone={onClose}
            />
          ) : (
            <ServiceList services={salon.services} onPick={setChosenService} />
          )}
        </div>
      </div>
    </div>
  );
}
