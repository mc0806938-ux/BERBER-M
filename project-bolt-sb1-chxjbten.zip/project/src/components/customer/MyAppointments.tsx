import { useEffect, useState } from 'react';
import { Banknote, CalendarDays, Loader2 } from 'lucide-react';
import { cancelAppointment, fetchMyAppointments } from '@/lib/bookingApi';
import { formatAppointmentDateTime } from '@/lib/istanbulTime';
import { formatPrice } from '@/lib/format';
import type { Appointment, AppointmentStatus } from '@/types/booking';

const STATUS_STYLES: Record<AppointmentStatus, { label: string; className: string }> = {
  pending: { label: 'Onay bekleniyor', className: 'bg-amber-50 text-amber-800 ring-amber-200' },
  confirmed: { label: 'Onaylandı', className: 'bg-forest-100 text-forest-800 ring-forest-200' },
  rejected: { label: 'Reddedildi', className: 'bg-red-50 text-red-700 ring-red-200' },
  cancelled: { label: 'İptal edildi', className: 'bg-forest-50 text-forest-800/70 ring-forest-100' },
};

const CANCELLABLE: AppointmentStatus[] = ['pending', 'confirmed'];

export default function MyAppointments() {
  const [appointments, setAppointments] = useState<Appointment[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchMyAppointments()
      .then((data) => {
        if (active) setAppointments(data);
      })
      .catch((err: Error) => {
        if (active) setError(err.message);
      });
    return () => {
      active = false;
    };
  }, [reloadKey]);

  const handleCancel = async (id: string) => {
    setBusyId(id);
    setActionError(null);
    try {
      await cancelAppointment(id);
      setConfirmingId(null);
      setAppointments(null);
      setReloadKey((key) => key + 1);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Randevu iptal edilemedi.');
    } finally {
      setBusyId(null);
    }
  };

  if (error) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center">
        <p className="text-sm font-medium text-red-700">{error}</p>
        <button
          type="button"
          onClick={() => {
            setError(null);
            setReloadKey((key) => key + 1);
          }}
          className="mt-4 rounded-xl bg-forest-800 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-forest-700"
        >
          Tekrar dene
        </button>
      </div>
    );
  }

  if (!appointments) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-7 w-7 animate-spin text-forest-600" />
      </div>
    );
  }

  if (appointments.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-forest-300 bg-white p-10 text-center">
        <CalendarDays className="mx-auto h-8 w-8 text-forest-600" />
        <h2 className="mt-4 text-lg font-bold text-forest-950">Henüz randevunuz yok</h2>
        <p className="mt-2 text-sm text-forest-800/75">Berberler sekmesinden bir salon seçip randevu talebi gönderebilirsiniz.</p>
      </div>
    );
  }

  return (
    <div>
      {actionError && (
        <p role="alert" className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
          {actionError}
        </p>
      )}
      <ul className="space-y-4">
        {appointments.map((appointment) => {
          const status = STATUS_STYLES[appointment.status];
          const cancellable = CANCELLABLE.includes(appointment.status);
          const isConfirming = confirmingId === appointment.id;
          return (
            <li key={appointment.id} className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="truncate text-base font-bold text-forest-950">{appointment.salon_name}</h2>
                  <p className="mt-1 text-sm text-forest-800/80">{appointment.service_name}</p>
                </div>
                <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset ${status.className}`}>
                  {status.label}
                </span>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-forest-900">
                <span className="flex items-center gap-1.5">
                  <CalendarDays className="h-4 w-4 text-forest-600" />
                  {formatAppointmentDateTime(appointment.starts_at)}
                </span>
                <span className="flex items-center gap-1.5">
                  <Banknote className="h-4 w-4 text-forest-600" />
                  {formatPrice(appointment.service_price_try)}
                </span>
              </div>

              {cancellable && (
                <div className="mt-4 border-t border-forest-100 pt-4">
                  {isConfirming ? (
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="text-sm text-forest-900">Randevunuzu iptal etmek istediğinize emin misiniz?</span>
                      <button
                        type="button"
                        disabled={busyId === appointment.id}
                        onClick={() => handleCancel(appointment.id)}
                        className="flex items-center gap-2 rounded-lg bg-red-600 px-3.5 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-700 disabled:opacity-60"
                      >
                        {busyId === appointment.id && <Loader2 className="h-4 w-4 animate-spin" />}
                        Evet, iptal et
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmingId(null)}
                        className="rounded-lg px-3.5 py-2 text-sm font-semibold text-forest-800 transition-colors hover:bg-forest-50"
                      >
                        Vazgeç
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmingId(appointment.id)}
                      className="rounded-lg px-3.5 py-2 text-sm font-semibold text-red-700 transition-colors hover:bg-red-50"
                    >
                      Randevuyu iptal et
                    </button>
                  )}
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
