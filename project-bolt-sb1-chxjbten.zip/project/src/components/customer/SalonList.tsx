import { useEffect, useState } from 'react';
import { ChevronRight, Loader2, MapPin, Scissors } from 'lucide-react';
import SalonSheet from '@/components/customer/SalonSheet';
import { fetchSalons } from '@/lib/bookingApi';
import { formatPrice } from '@/lib/format';
import type { Salon } from '@/types/booking';

export default function SalonList() {
  const [salons, setSalons] = useState<Salon[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Salon | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let active = true;
    fetchSalons()
      .then((data) => {
        if (active) setSalons(data);
      })
      .catch((err: Error) => {
        if (active) setError(err.message);
      });
    return () => {
      active = false;
    };
  }, [reloadKey]);

  if (error) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center">
        <p className="text-sm font-medium text-red-700">{error}</p>
        <button
          type="button"
          onClick={() => {
            setError(null);
            setReloadKey((key) => key + 1);
          }}
          className="mt-4 rounded-xl bg-forest-800 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-forest-700"
        >
          Tekrar dene
        </button>
      </div>
    );
  }

  if (!salons) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-7 w-7 animate-spin text-forest-600" />
      </div>
    );
  }

  if (salons.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-forest-300 bg-white p-10 text-center">
        <Scissors className="mx-auto h-8 w-8 text-forest-600" />
        <h2 className="mt-4 text-lg font-bold text-forest-950">Henüz berber eklenmedi</h2>
        <p className="mt-2 text-sm text-forest-800/75">Berberler salonlarını oluşturduğunda burada listelenecek.</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {salons.map((salon) => {
          const startingPrice = salon.services.length
            ? Math.min(...salon.services.map((service) => service.price_try))
            : null;
          return (
            <button
              key={salon.id}
              type="button"
              onClick={() => setSelected(salon)}
              className="group flex flex-col rounded-2xl border border-forest-100 bg-white p-5 text-left shadow-card transition-all hover:-translate-y-1 hover:border-forest-200"
            >
              <div className="flex items-start gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-forest-800 text-lg font-bold text-white">
                  {salon.name.charAt(0).toUpperCase()}
                </span>
                <div className="min-w-0">
                  <h2 className="truncate text-base font-bold text-forest-950">{salon.name}</h2>
                  {salon.address && (
                    <p className="mt-1 flex items-start gap-1.5 text-sm text-forest-800/75">
                      <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                      <span className="line-clamp-2">{salon.address}</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between border-t border-forest-100 pt-4">
                <span className="text-sm text-forest-800/80">
                  {startingPrice !== null ? (
                    <>
                      Başlangıç <span className="font-bold text-forest-900">{formatPrice(startingPrice)}</span>
                    </>
                  ) : (
                    'Hizmet henüz eklenmedi'
                  )}
                </span>
                <span className="flex items-center gap-1 text-sm font-semibold text-forest-700 transition-transform group-hover:translate-x-0.5">
                  İncele
                  <ChevronRight className="h-4 w-4" />
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {selected && <SalonSheet salon={selected} onClose={() => setSelected(null)} />}
    </>
  );
}
