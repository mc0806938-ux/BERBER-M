import { Scissors } from 'lucide-react';

interface BrandLogoProps {
  tone?: 'dark' | 'light';
}

export default function BrandLogo({ tone = 'dark' }: BrandLogoProps) {
  const isLight = tone === 'light';
  return (
    <div className="flex items-center gap-2.5">
      <span
        className={`flex h-9 w-9 items-center justify-center rounded-xl ${
          isLight ? 'bg-white text-forest-800' : 'bg-forest-800 text-white'
        }`}
      >
        <Scissors className="h-5 w-5" strokeWidth={2.25} />
      </span>
      <span className={`text-lg font-bold tracking-tight ${isLight ? 'text-white' : 'text-forest-900'}`}>
        Berberim
      </span>
    </div>
  );
}
