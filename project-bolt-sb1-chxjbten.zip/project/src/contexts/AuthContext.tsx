import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { Profile, UserRole } from '@/types/profile';

export interface SignUpParams {
  email: string;
  password: string;
  username: string;
  role: UserRole;
}

export type SignUpResult =
  | { status: 'signed_in' }
  | { status: 'check_email' }
  | { status: 'error'; message: string };

interface AuthContextValue {
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string, role: UserRole) => Promise<string | null>;
  signUp: (params: SignUpParams) => Promise<SignUpResult>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const ROLE_MISMATCH_MESSAGE = 'Bu hesap bu giriş türüne ait değil. Lütfen doğru giriş ekranını kullanın.';
const PROFILE_ERROR_MESSAGE = 'Hesap bilgileriniz alınamadı. Lütfen tekrar deneyin.';

export function translateAuthError(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('invalid login credentials')) return 'E-posta veya şifre hatalı.';
  if (lower.includes('email not confirmed')) return 'E-posta adresiniz henüz onaylanmamış.';
  if (lower.includes('already registered') || lower.includes('already been registered')) {
    return 'Bu e-posta ile zaten bir hesap var.';
  }
  if (lower.includes('database error saving new user')) {
    return 'Bu kullanıcı adı zaten alınmış. Lütfen farklı bir kullanıcı adı deneyin.';
  }
  if (lower.includes('password should be at least')) return 'Şifre en az 6 karakter olmalı.';
  if (lower.includes('invalid email')) return 'Lütfen geçerli bir e-posta adresi girin.';
  if (lower.includes('rate limit') || lower.includes('too many')) {
    return 'Çok fazla deneme yapıldı. Lütfen biraz bekleyip tekrar deneyin.';
  }
  if (lower.includes('failed to fetch') || lower.includes('network')) {
    return 'Bağlantı kurulamadı. İnternet bağlantınızı kontrol edin.';
  }
  return 'Bir hata oluştu, lütfen tekrar deneyin.';
}

async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, role, full_name, phone, avatar_path')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw error;
  return data as Profile | null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const loginInProgress = useRef(false);

  useEffect(() => {
    const { data: subscription } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      (async () => {
        if (loginInProgress.current) return;
        if (!nextSession) {
          setSession(null);
          setProfile(null);
          setLoading(false);
          return;
        }
        try {
          setProfile(await fetchProfile(nextSession.user.id));
        } catch {
          setProfile(null);
        }
        setSession(nextSession);
        setLoading(false);
      })();
    });
    return () => subscription.subscription.unsubscribe();
  }, []);

  const signIn = useCallback(async (email: string, password: string, role: UserRole) => {
    loginInProgress.current = true;
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return translateAuthError(error.message);
      if (!data.session) return PROFILE_ERROR_MESSAGE;

      let existing: Profile | null;
      try {
        existing = await fetchProfile(data.session.user.id);
      } catch {
        existing = null;
      }
      if (!existing) {
        await supabase.auth.signOut();
        return PROFILE_ERROR_MESSAGE;
      }
      if (existing.role !== role) {
        await supabase.auth.signOut();
        return ROLE_MISMATCH_MESSAGE;
      }

      setProfile(existing);
      setSession(data.session);
      return null;
    } finally {
      loginInProgress.current = false;
    }
  }, []);

  const signUp = useCallback(async ({ email, password, username, role }: SignUpParams): Promise<SignUpResult> => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { role, username } },
    });
    if (error) return { status: 'error', message: translateAuthError(error.message) };
    if (!data.session) return { status: 'check_email' };
    return { status: 'signed_in' };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const refreshProfile = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) return;
    try {
      setProfile(await fetchProfile(data.session.user.id));
    } catch {
      return;
    }
  }, []);

  const value = useMemo(
    () => ({ session, profile, loading, signIn, signUp, signOut, refreshProfile }),
    [session, profile, loading, signIn, signUp, signOut, refreshProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
